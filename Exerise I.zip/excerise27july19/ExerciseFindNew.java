package excerise27july19;

import java.util.Scanner;

public class ExerciseFindNew {
	static int choice;
	public static void main(String []args)
	{
			FindSumAver fs =  new FindSumAver();
			fs.getInput();
			fs.display();
			FindSqrCub fc = new FindSqrCub();
			fc.getInput();
			fc.displaySquare();
			fc.displayCube();
			FindOdd fo = new FindOdd();
			fo.getInput();
			fo.display();
			fo.display1();
			fo.display2();
			FindEven fe = new FindEven();
			fe.getInput();
			fe.display();
			FindReverse fr = new FindReverse();
			fr.getInput();
			fr.reverse();
			fr.reverse1();
			Stringprogram sp = new Stringprogram();
			sp.getInput();
			sp.display();
			Vote v = new Vote();
			v.getInput();
			v.findEligibleVote();
	   
}
}
