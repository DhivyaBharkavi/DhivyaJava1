package excerise27july19;

import java.util.Scanner;

public class ExerciseFind {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean b = true;
		while(b)
			{
		System.out.println("Menu");
		System.out.println("1. Sum and Average");
		System.out.println("2. Square and Cube");
		System.out.println("3. Odd Series");
		System.out.println("4. Even Series");
		System.out.println("5. Range in reverse order");
		System.out.println("6. Reverse Number or Not");
		System.out.println("7. Eligible to Vote or Not");
		System.out.println("8. My field of Interest");
		System.out.println("9. Connecting two name using String");
		System.out.println("10. Calculator");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		int cc = sc.nextInt();
		if(cc == 1)
		{ 
		FindSumAver fs =  new FindSumAver();
		fs.getInput();
		fs.display();
		}
		else if(cc == 2)
		{
		FindSqrCub fc = new FindSqrCub();
		fc.getInput();
		fc.displaySquare();
		fc.displayCube();
		}
		else if(cc == 3)
		{
		FindOdd fo = new FindOdd();
		fo.getInput();
		fo.display();
		fo.display1();
		//fo.display2();
		}
		else if(cc ==4)
		{
		FindEven fe = new FindEven();
		fe.getInput();
		fe.display();
		}
		else if(cc==5)
		{
			Range r = new Range();
			r.getInput();
			r.reverse();
			r.forward();
		}
		else if(cc ==6)
		{
		FindReverse fr = new FindReverse();
		fr.getInput();
		fr.reverse();
		fr.reverse1();
		}
		else if(cc==7)
		{
			Vote v = new Vote();
			v.getInput();
			v.findEligibleVote();
		}
		else if(cc==8)
		{
		MyField mf = new MyField();
		mf.getInput();
		mf.display();
		}
		else if(cc == 9)
		{
		Stringprogram sp = new Stringprogram();
		sp.getInput();
		sp.display();
	    }
		else if(cc ==10 )
		{
			boolean b1 = true;
			while(b1)
				{
					Calculator c = new Calculator();
					System.out.println("Menu");
					System.out.println("1. Addition");
					System.out.println("2. Subtraction");
					System.out.println("3. Multiplication");
					System.out.println("4. Division");
					System.out.println("5. Modulation");
					Scanner s = new Scanner(System.in);
					System.out.println("Enter your choice");
					int ch = s.nextInt();
					c.getInput();
					if(ch ==1)
					{
						c.add();
					}
					else if(ch ==2)
					{
						c.sub();
					}
					else if(ch ==3)
					{
						c.mul();
					}
					else if(ch ==4)
					{
						c.div();
					}
					else if(ch ==5)
					{
						c.mod();
					}
					else
					{
						System.out.println("Wrong choice ");
					}
					System.out.println("Do you want continue (y/n)");
					char co = sc.next().charAt(0);
					if(co == 'n')
					{
					 b1= false;
					
					}	
					
					else
					{
						System.out.println("Wrong choice ");
					}
					System.out.println("Do you want continue (y/n)");
					char cco = sc.next().charAt(0);
					if(cco == 'n')
					{
					 b= false;
					
					}	
		
			}
}
	}
	}
}
