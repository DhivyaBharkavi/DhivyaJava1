package excerise27july19;

import java.util.Scanner;

public class Vote {
int age;
void getInput()
{
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter age is");
	age=scan.nextInt();
}
void findEligibleVote()
{
	if (age >=18)
	{
		System.out.println(age+ " is eligible to vote");
	}
		else if(age <=18)
		{
			System.out.println(age+ " is not eligible to vote");	
		}
		else
		{
			System.out.println("No vote");
		}
	}
}

