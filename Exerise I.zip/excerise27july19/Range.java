package excerise27july19;

import java.util.Scanner;

public class Range {
	int n;
	void getInput()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter value is");
		n=scan.nextInt();
	}
	void reverse()
	{
		System.out.println("Reverse range \n");
		for(int i=n;i>=1;i--)
		{
		System.out.print(" "+i+"\t");
		//System.out.println("\n" );	
		}
	}
	void forward()
	{
		System.out.println("\nForward range \n");
		for(int i=0;i<=n;i++)
		{
		System.out.print(" "+i+"\t");
		}
		System.out.println("\n" );	
		
	}
}
