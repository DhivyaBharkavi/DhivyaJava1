package excerise27july19;

import java.util.Scanner;

public class FindSqrCub {
int value1,result,result1;
void getInput()
{
Scanner scan = new Scanner(System.in);
System.out.println("Enter the value1 is ");
value1=scan.nextInt();
}
void displaySquare()
{
	result=value1 * value1;
	System.out.println("Square of " + value1 + " is "+result );
}
void displayCube()
{
	result1=value1 * value1 * value1;
	System.out.println("Cube of " + value1 + " is " +result1 );
}
}
