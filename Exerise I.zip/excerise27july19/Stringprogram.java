package excerise27july19;

import java.util.Scanner;

public class Stringprogram {
String name ;
String name1;
void getInput()
{
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter first name is ");
	name=scan.nextLine();
	System.out.println("Enter second name is ");
	name1=scan.nextLine();
}
void display()
{
	System.out.println(name+name1);
}
}
