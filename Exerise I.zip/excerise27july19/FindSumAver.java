package excerise27july19;

import java.util.Scanner;

public class FindSumAver {
int number1,number2,number3,sum,average;
void getInput()
{
Scanner scan = new Scanner(System.in);
System.out.println("Enter number1 value ");
number1=scan.nextInt();
System.out.println("Enter number2 value ");
number2=scan.nextInt();
System.out.println("Enter number3 value ");
number3=scan.nextInt();
}
void display()
{
	sum = number1+number2+number3;
	average=sum/3;
	System.out.println("Sum is "+sum);
	System.out.println("Average is "+average);
	
}
}
