package excerise27july19;

import java.util.Scanner;

public class MyField {
	String name,rollno,fieldOfInterest;
	Scanner scan = new Scanner(System.in);
	void getInput()
	{
		
		System.out.println("Enter a rollno ");
		rollno=scan.next();
		System.out.println("Enter a name ");
		name=scan.next();
		System.out.println("Enter a field of interest ");
		fieldOfInterest=scan.next();
	}
	void display()
	{
		System.out.println("Roll no           "+rollno);
		System.out.println("Name              "+name);
		System.out.println("Field of Interest "+fieldOfInterest);
	}
}
