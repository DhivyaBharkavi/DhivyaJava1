package excerise27july19;

import java.util.Scanner;
//import.java.lang.ArithmeticException;
public class FindOdd {
int value;
int i,result;
void getInput()
{
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter value is");
	value=scan.nextInt();
}
void display()
{
	System.out.print("The odd numbers is \n");	
	
	for(i=1;i<=value;i++)
	{
		result=i % 2;
		if(result !=0)
		System.out.print(i + "\t   ");
	}
	System.out.println("\n");
}
void display1()
{
	System.out.print("The odd numbers is\n ");	
	
	for(i=1;i<=value;i++)
	{
		System.out.print(2 * i - 1+ "\t " );
	}	
	System.out.println("\n");
}
/*void display2()
{
	System.out.print("The odd numbers is ");	
	
	for(i=1;i<=value;i++)
	{
		System.out.println(" " +(2 * i + 1)+ " " );
		//System.out.println("\n");
		
	}
}*/
}
