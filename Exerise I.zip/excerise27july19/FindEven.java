package excerise27july19;

import java.util.Scanner;

public class FindEven {
	int value;
	int i,result;
	void getInput()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter value is");
		value=scan.nextInt();
	}
	void display()
	{
		System.out.print("The even numbers is \n ");	
		
		for(i=1;i<=value;i++)
		{
			result=i % 2;
			if(result == 0 )
			
			System.out.print(i+ "\t ");
		}
		System.out.println("\n");
	}
}
