package excerise27july19;

import java.util.Scanner;

public class FindReverse {
int reverse,value;
void getInput()
{
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter value is");
	value=scan.nextInt();
}
void reverse()
{
	if(value % 10 ==1 )
	{
		System.out.println("This is a reverse number is "+value);
	}
	
	else if(value % 10 != 1) 
	{
		System.out.println("This is not a reverse number is "+value);

	}
		else
	{
		System.out.println("No value");
	}
	
}
void reverse1()
{
	int res=value%10;
	res=value/10;
	System.out.println("Reverse Number is "+res);
}


}
