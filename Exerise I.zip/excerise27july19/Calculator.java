package excerise27july19;

import java.util.Scanner;

public class Calculator {
int number1,number2;
void getInput()
{
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter a value ");
	number1=scan.nextInt();
	System.out.println("Enter a value ");
	number2=scan.nextInt();
}
void add()
{
	System.out.println("Addition is "+(number1+number2));
}
void sub()
{
	System.out.println("Subtraction is "+(number1-number2));
}
void mul()
{
	System.out.println("Multiplication is "+(number1*number2));
}
void div()
{
	System.out.println("Division is "+(number1/number2));
}
void mod()
{
	System.out.println("Modulation is "+(number1%number2));
}
}
